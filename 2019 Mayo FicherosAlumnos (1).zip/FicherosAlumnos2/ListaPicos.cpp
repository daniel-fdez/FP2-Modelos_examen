/*
   Apellidos y Nombre:
   Puesto:
*/

#include "ListaPicos.h"
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;


// Implementa las funciones solicitadas
