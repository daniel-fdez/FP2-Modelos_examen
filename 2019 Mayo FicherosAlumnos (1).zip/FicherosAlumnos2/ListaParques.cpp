/*
   Apellidos y Nombre:
   Puesto:
*/

#include "ListaParques.h"
#include <math.h>  // abs
using namespace std;


// Implementa las funciones solicitadas

