/*
   Apellidos y Nombre:
   Puesto:
*/

#ifndef _listaPicos
#define _listaPicos
#include<string>
#include "Parque.h"
using namespace std;


// Define la estructura

//Prototipos

#endif
