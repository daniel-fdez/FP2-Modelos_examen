/*
   Apellidos y Nombre:
   Puesto:
*/

#ifndef _listaParques
#define _listaParques
#include<string>
#include "Parque.h"
using namespace std;

const int MAX_PARQUES = 400;

// Define la estructura

//Prototipos

#endif
